function showDiv() {
    var hiddenDiv = document.getElementById("hiddenDiv");
    hiddenDiv.style.display = "block";
}

function hideDiv() {
    var hiddenDiv = document.getElementById("hiddenDiv");
    hiddenDiv.style.display = "none";
}