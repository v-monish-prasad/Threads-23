const auth = firebase.auth()
const db = firebase.firestore()
const database = firebase.database()
var databas = firebase.database();
const dbRef = firebase.database().ref()

let message="sangeetha.22cse@sonatech.ac.in subashree.22cse@sonatech.ac.in venkat.22cse@sonatech.ac.in aabidhabegum.22cse@sonatech.ac.in abinayak.22cse@sonatech.ac.in abinayam.22cse@sonatech.ac.in abishek.22cse@sonatech.ac.in abisheksingh.22cse@sonatech.ac.in ajithkumar.22cse@sonatech.ac.in akshaya.22cse@sonatech.ac.in anandanarayanan.22cse@sonatech.ac.in annapoorani.22cse@sonatech.ac.in aravinth.22cse@sonatech.ac.in arunkarthikeyan.22cse@sonatech.ac.in arvinth.22cse@sonatech.ac.in asmaragamath.22cse@sonatech.ac.in asmathhazeena.22cse@sonatech.ac.in barathviswam.22cse@sonatech.ac.in bharath.22cse@sonatech.ac.in darwinprabu.22cse@sonatech.ac.in devesh.22cse@sonatech.ac.in dhanusiya.22cse@sonatech.ac.in dharshinicr.22cse@sonatech.ac.in dharshinid.22cse@sonatech.ac.in dharshinir.22cse@sonatech.ac.in dharsini.22cse@sonatech.ac.in dharunkumar.22cse@sonatech.ac.in dheepika.22cse@sonatech.ac.in dhonikarthick.22cse@sonatech.ac.in dineshkumar.22cse@sonatech.ac.in dinesh.22cse@sonatech.ac.in diwakar.22cse@sonatech.ac.in eswin.22cse@sonatech.ac.in gayathripriya.22cse@sonatech.ac.in geethaipiriya.22cse@sonatech.ac.in girivasan.22cse@sonatech.ac.in gokul.22cse@sonatech.ac.in gopalakrishnan.22cse@sonatech.ac.in hariarjun.22cse@sonatech.ac.in hariharan.22cse@sonatech.ac.in harikrishna.22cse@sonatech.ac.in harinee.22cse@sonatech.ac.in harini.22cse@sonatech.ac.in harinis.22cse@sonatech.ac.in harshiv.22cse@sonatech.ac.in hinduja.22cse@sonatech.ac.in ilakkiya.22cse@sonatech.ac.in jaimanisa.22cse@sonatech.ac.in janani.22cse@sonatech.ac.in jananisri.22cse@sonatech.ac.in jathincramesh.22cse@sonatech.ac.in jayasurya.22cse@sonatech.ac.in jayavarsha.22cse@sonatech.ac.in jeevajothibalan.22cse@sonatech.ac.in kakanitarun.22cse@sonatech.ac.in kamrunnisha.22cse@sonatech.ac.in kanika.22cse@sonatech.ac.in kanimozhi.22cse@sonatech.ac.in kanishkadevi.22cse@sonatech.ac.in kanishma.22cse@sonatech.ac.in karthick.22cse@sonatech.ac.in karthikragul.22cse@sonatech.ac.in kavishka.22cse@sonatech.ac.in keerthi.22cse@sonatech.ac.in kharthikeya.22cse@sonatech.ac.in kiruthikaa.22cse@sonatech.ac.in kishore.22cse@sonatech.ac.in kreeshab.22cse@sonatech.ac.in logapriyam.22cse@sonatech.ac.in logapriyar.22cse@sonatech.ac.in madhan.22cse@sonatech.ac.in madhanraj.22cse@sonatech.ac.in madhushree.22cse@sonatech.ac.in mahalakshmi.22cse@sonatech.ac.in maharishi.22cse@sonatech.ac.in malarvizhi.22cse@sonatech.ac.in manasa.22cse@sonatech.ac.in manoranjan.22cse@sonatech.ac.in megha.22cse@sonatech.ac.in mehashree.22cse@sonatech.ac.in midhulasri.22cse@sonatech.ac.in monikasri.22cse@sonatech.ac.in mounika.22cse@sonatech.ac.in mounish.22cse@sonatech.ac.in mouthini.22cse@sonatech.ac.in mukesh.22cse@sonatech.ac.in muraliprashad.22cse@sonatech.ac.in musharaf.22cse@sonatech.ac.in nandhinisri.22cse@sonatech.ac.in natchatraa.22cse@sonatech.ac.in naveenraj.22cse@sonatech.ac.in navroj.22cse@sonatech.ac.in neghashree.22cse@sonatech.ac.in nisha.22cse@sonatech.ac.in padmadharshini.22cse@sonatech.ac.in pallavarapurichitha.22cse@sonatech.ac.in parvat.22cse@sonatech.ac.in patolesudipamol.22cse@sonatech.ac.in poojaniranjana.22cse@sonatech.ac.in poojasri.22cse@sonatech.ac.in poovarasi.22cse@sonatech.ac.in pradhishraj.22cse@sonatech.ac.in pragadeesh.22cse@sonatech.ac.in pranav.22cse@sonatech.ac.in pratishaarya.22cse@sonatech.ac.in praveen.22cse@sonatech.ac.in praveenkumargk.22cse@sonatech.ac.in praveenkumarg.22cse@sonatech.ac.in praveenkumarm.22cse@sonatech.ac.in prithika.22cse@sonatech.ac.in priyadharshini.22cse@sonatech.ac.in priyangga.22cse@sonatech.ac.in ragul.22cse@sonatech.ac.in rahul.22cse@sonatech.ac.in rajkapoorjaiswal.22cse@sonatech.ac.in rajalakshmi.22cse@sonatech.ac.in ramapriya.22cse@sonatech.ac.in ramesh.22cse@sonatech.ac.in riddhimchawla.22cse@sonatech.ac.in rishikesh.22cse@sonatech.ac.in rithishanto.22cse@sonatech.ac.in rubigaa.22cse@sonatech.ac.in sachin.22cse@sonatech.ac.in sandeeprishi.22cse@sonatech.ac.in sandhiya.22cse@sonatech.ac.in sanjay.22cse@sonatech.ac.in sanjeev.22cse@sonatech.ac.in sanjithbala.22cse@sonatech.ac.in sanjith.22cse@sonatech.ac.in santhoshp.22cse@sonatech.ac.in santhoshs.22cse@sonatech.ac.in santhosh.22cse@sonatech.ac.in sashwataryal.22cse@sonatech.ac.in savitha.22cse@sonatech.ac.in senthamizh.22cse@sonatech.ac.in shaaheer.22cse@sonatech.ac.in sharmilabanu.22cse@sonatech.ac.in sheela.22cse@sonatech.ac.in sheikabdulla.22cse@sonatech.ac.in shivamkumar.22cse@sonatech.ac.in shivani.22cse@sonatech.ac.in shivanikha.22cse@sonatech.ac.in shobhanaa.22cse@sonatech.ac.in shobia.22cse@sonatech.ac.in shreeramm.22cse@sonatech.ac.in shriharini.22cse@sonatech.ac.in shrimath.22cse@sonatech.ac.in sivaprakash.22cse@sonatech.ac.in sonali.22cse@sonatech.ac.in sowmiya.22cse@sonatech.ac.in sreemathi.22cse@sonatech.ac.in sridevi.22cse@sonatech.ac.in sriharan.22cse@sonatech.ac.in sriharshini.22cse@sonatech.ac.in srinevetha.22cse@sonatech.ac.in subashini.22cse@sonatech.ac.in subathra.22cse@sonatech.ac.in subiksha.22cse@sonatech.ac.in suchitra.22cse@sonatech.ac.in sudharsan.22cse@sonatech.ac.in sujjith.22cse@sonatech.ac.in surabhi.22cse@sonatech.ac.in suryavel.22cse@sonatech.ac.in swethag.22cse@sonatech.ac.in swethal.22cse@sonatech.ac.in tamilselvan.22cse@sonatech.ac.in tharun.22cse@sonatech.ac.in tharunprasanth.22cse@sonatech.ac.in thigazhavan.22cse@sonatech.ac.in thisanthan.22cse@sonatech.ac.in tirumurugaa.22cse@sonatech.ac.in vaishnavias.22cse@sonatech.ac.in vaishnavim.22cse@sonatech.ac.in varshini.22cse@sonatech.ac.in varunkumar.22cse@sonatech.ac.in vasuda.22cse@sonatech.ac.in vedaprakash.22cse@sonatech.ac.in velmurugan.22cse@sonatech.ac.in venkattalakshmi.22cse@sonatech.ac.in vignesh.22cse@sonatech.ac.in vijayadithya.22cse@sonatech.ac.in vijayadharshini.22cse@sonatech.ac.in vikash.22cse@sonatech.ac.in vikkramvigneswaran.22cse@sonatech.ac.in vimalvidyadhaaran.22cse@sonatech.ac.in vinoth.22cse@sonatech.ac.in vinothini.22cse@sonatech.ac.in vinudevi.22cse@sonatech.ac.in visalini.22cse@sonatech.ac.in vishva.22cse@sonatech.ac.in vishwa.22cse@sonatech.ac.in vivegaa.22cse@sonatech.ac.in vyshnavi.22cse@sonatech.ac.in abinayashree.22csd@sonatech.ac.in abiraami.22csd@sonatech.ac.in anandan.22csd@sonatech.ac.in anchalkumari.22csd@sonatech.ac.in bharath.22csd@sonatech.ac.in boobalan.22csd@sonatech.ac.in dharshini.22csd@sonatech.ac.in geetharanjani.22csd@sonatech.ac.in gowsika.22csd@sonatech.ac.in gowthamb.22csd@sonatech.ac.in gowthamv.22csd@sonatech.ac.in harivignesh.22csd@sonatech.ac.in harini.22csd@sonatech.ac.in hiriharan.22csd@sonatech.ac.in iswarya.22csd@sonatech.ac.in jayanthigha.22csd@sonatech.ac.in kamalnath.22csd@sonatech.ac.in karthikeyan.22csd@sonatech.ac.in kishanthsharma.22csd@sonatech.ac.in kishorekumars.22csd@sonatech.ac.in kishorekumarv.22csd@sonatech.ac.in kokilavani.22csd@sonatech.ac.in logeshkumar.22csd@sonatech.ac.in manisharma.22csd@sonatech.ac.in manoj.22csd@sonatech.ac.in mirinazhine.22csd@sonatech.ac.in mithun.22csd@sonatech.ac.in monishraj.22csd@sonatech.ac.in mukilan.22csd@sonatech.ac.in nithish.22csd@sonatech.ac.in nitish.22csd@sonatech.ac.in oliveatresa.22csd@sonatech.ac.in oviya.22csd@sonatech.ac.in pavithra.22csd@sonatech.ac.in prabakaran.22csd@sonatech.ac.in pravin.22csd@sonatech.ac.in preethidevi.22csd@sonatech.ac.in premkumar.22csd@sonatech.ac.in priyadharshan.22csd@sonatech.ac.in queenyabichristy.22csd@sonatech.ac.in rajaganapathi.22csd@sonatech.ac.in rajakumari.22csd@sonatech.ac.in rasikaasree.22csd@sonatech.ac.in ravi.22csd@sonatech.ac.in roshankumar.22csd@sonatech.ac.in sahanag.22csd@sonatech.ac.in sahanav.22csd@sonatech.ac.in sasikumar.22csd@sonatech.ac.in shahinbegum.22csd@sonatech.ac.in shubhasree.22csd@sonatech.ac.in sidharth.22csd@sonatech.ac.in sowmiyarajalakshmi.22csd@sonatech.ac.in srikaviya.22csd@sonatech.ac.in srikanth.22csd@sonatech.ac.in sriram.22csd@sonatech.ac.in subathra.22csd@sonatech.ac.in suji.22csd@sonatech.ac.in vignesh.22csd@sonatech.ac.in vijayathithya.22csd@sonatech.ac.in vishnupriyan.22csd@sonatech.ac.in yogesh.22csd@sonatech.ac.in abinaya.22aml@sonatech.ac.in akramjavith.22aml@sonatech.ac.in anushadsingh.22aml@sonatech.ac.in anusuyya.22aml@sonatech.ac.in arun.22aml@sonatech.ac.in arunkumar.22aml@sonatech.ac.in ashwin.22aml@sonatech.ac.in balajihanumankatkar.22aml@sonatech.ac.in bharanitharan.22aml@sonatech.ac.in bharath.22aml@sonatech.ac.in devadharshini.22aml@sonatech.ac.in dharshana.22aml@sonatech.ac.in dhinakar.22aml@sonatech.ac.in dinesh.22aml@sonatech.ac.in elavarasi.22aml@sonatech.ac.in girish.22aml@sonatech.ac.in gobinath.22aml@sonatech.ac.in gokul.22aml@sonatech.ac.in hemashruthi.22aml@sonatech.ac.in hemasree.22aml@sonatech.ac.in jafrinnidha.22aml@sonatech.ac.in jaisudharshan.22aml@sonatech.ac.in jeevavishnu.22aml@sonatech.ac.in jenita.22aml@sonatech.ac.in kabilan.22aml@sonatech.ac.in kanishka.22aml@sonatech.ac.in karthiksriram.22aml@sonatech.ac.in karthikeyan.22aml@sonatech.ac.in laya.22aml@sonatech.ac.in lingeshwaran.22aml@sonatech.ac.in madhumitha.22aml@sonatech.ac.in maisarafathima.22aml@sonatech.ac.in manoj.22aml@sonatech.ac.in menakasri.22aml@sonatech.ac.in mohamedkaif.22aml@sonatech.ac.in navin.22aml@sonatech.ac.in nishapriya.22aml@sonatech.ac.in prabha.22aml@sonatech.ac.in pranitha.22aml@sonatech.ac.in prewittagassi.22aml@sonatech.ac.in rithika.22aml@sonatech.ac.in rohith.22aml@sonatech.ac.in sadaasivam.22aml@sonatech.ac.in sanjana.22aml@sonatech.ac.in sanjeevikumar.22aml@sonatech.ac.in sanjushree.22aml@sonatech.ac.in shanmithaa.22aml@sonatech.ac.in shanmugeshwaran.22aml@sonatech.ac.in shreebalan.22aml@sonatech.ac.in shreelekhaa.22aml@sonatech.ac.in sivaganesh.22aml@sonatech.ac.in sivashree.22aml@sonatech.ac.in sridevi.22aml@sonatech.ac.in sruti.22aml@sonatech.ac.in subashkrishnan.22aml@sonatech.ac.in sunantha.22aml@sonatech.ac.in tarun.22aml@sonatech.ac.in thameena.22aml@sonatech.ac.in thirumurugan.22aml@sonatech.ac.in venkatesan.22aml@sonatech.ac.in vignesh.22aml@sonatech.ac.in yogapraveen.22aml@sonatech.ac.in aakash.21cse@sonatech.ac.in aarthi.21cse@sonatech.ac.in abhijit.21cse@sonatech.ac.in abishek.21cse@sonatech.ac.in adithya.21cse@sonatech.ac.in ahish.21cse@sonatech.ac.in akshaya.21cse@sonatech.ac.in amsaveni.21cse@sonatech.ac.in anandh.21cse@sonatech.ac.in anandhan.21cse@sonatech.ac.in ankitkumar.21cse@sonatech.ac.in aravinth.21cse@sonatech.ac.in archana.21cse@sonatech.ac.in arcsithraj.21cse@sonatech.ac.in arulkarthikeyan.21cse@sonatech.ac.in arun.21cse@sonatech.ac.in avishya.21cse@sonatech.ac.in balakumaran.21cse@sonatech.ac.in baranibabu.21cse@sonatech.ac.in bharanisivam.21cse@sonatech.ac.in bhoopesh.21cse@sonatech.ac.in boopathiraja.21cse@sonatech.ac.in chaithra.21cse@sonatech.ac.in deekshitha.21cse@sonatech.ac.in deepakraj.21cse@sonatech.ac.in deepika.21cse@sonatech.ac.in dhakshatha.21cse@sonatech.ac.in dhanusree.21cse@sonatech.ac.in dhanush.21cse@sonatech.ac.in dharani.21cse@sonatech.ac.in dharshiniac.21cse@sonatech.ac.in dharshinid.21cse@sonatech.ac.in dharshiniv.21cse@sonatech.ac.in dhinesh.21cse@sonatech.ac.in divyapoorani.21cse@sonatech.ac.in elakiya.21cse@sonatech.ac.in gangadharan.21cse@sonatech.ac.in gayathri.21cse@sonatech.ac.in giritharan.21cse@sonatech.ac.in gnanasundar.21cse@sonatech.ac.in gokulakannan.21cse@sonatech.ac.in goushik.21cse@sonatech.ac.in gouthemprasath.21cse@sonatech.ac.in hareni.21cse@sonatech.ac.in harivaishnavi.21cse@sonatech.ac.in harini.21cse@sonatech.ac.in harish.21cse@sonatech.ac.in jeevanatham.21cse@sonatech.ac.in prabu.21cse@sonatech.ac.in thamarikannan.21cse@sonatech.ac.in chintaginjalapenchalaprasanth.21cse@sonatech.ac.in hariprasad.21cse@sonatech.ac.in harshini.21cse@sonatech.ac.in hemapriya.21cse@sonatech.ac.in induja.21cse@sonatech.ac.in infantcalvin.21cse@sonatech.ac.in jagadesvar.21cse@sonatech.ac.in janagan.21cse@sonatech.ac.in jananigk.21cse@sonatech.ac.in jananip.21cse@sonatech.ac.in jatheen.21cse@sonatech.ac.in joselinjanet.21cse@sonatech.ac.in jothilakshmi.21cse@sonatech.ac.in kamali.21cse@sonatech.ac.in kanimozhi.21cse@sonatech.ac.in kanishkag.21cse@sonatech.ac.in kanishkas.21cse@sonatech.ac.in karansridharan.21cse@sonatech.ac.in karthick.21cse@sonatech.ac.in karthik.21cse@sonatech.ac.in karthikeyan.21cse@sonatech.ac.in kathiresan.21cse@sonatech.ac.in kavidharshna.21cse@sonatech.ac.in keerthiga.21cse@sonatech.ac.in kishorekumar.21cse@sonatech.ac.in kowsalya.21cse@sonatech.ac.in kowsic.21cse@sonatech.ac.in koyisiva.21cse@sonatech.ac.in krithigha.21cse@sonatech.ac.in kumanan.21cse@sonatech.ac.in kumaresh.21cse@sonatech.ac.in lakshitha.21cse@sonatech.ac.in lavanyat.21cse@sonatech.ac.in logaprasath.21cse@sonatech.ac.in logeshvar.21cse@sonatech.ac.in loghamaniya.21cse@sonatech.ac.in lokesh.21cse@sonatech.ac.in madhappan.21cse@sonatech.ac.in madhumithaa.21cse@sonatech.ac.in manjari.21cse@sonatech.ac.in manoj.21cse@sonatech.ac.in meenatchi.21cse@sonatech.ac.in mohamedvasim.21cse@sonatech.ac.in mohammedibrahimhussain.21cse@sonatech.ac.in mohammedkashif.21cse@sonatech.ac.in mullapudidurgaphanindra.21cse@sonatech.ac.in muniappan.21cse@sonatech.ac.in SAICHARANMUNNANGI.21cse@sonatech.ac.in nandhavelan.21cse@sonatech.ac.in rohinthkr.21cse@sonatech.ac.in makeshhariharan.21cse@sonatech.ac.in sachin.21cse@sonatech.ac.in nandhana.21cse@sonatech.ac.in nandhini.21cse@sonatech.ac.in naresh.21cse@sonatech.ac.in navanitha.21cse@sonatech.ac.in naveen.21cse@sonatech.ac.in nelsonmandela.21cse@sonatech.ac.in nikil.21cse@sonatech.ac.in ninoaugus.21cse@sonatech.ac.in niranjhana.21cse@sonatech.ac.in nitheeshprahalath.21cse@sonatech.ac.in nithisha.21cse@sonatech.ac.in nithiyashini.21cse@sonatech.ac.in nithyashree.21cse@sonatech.ac.in nithyashri.21cse@sonatech.ac.in nitish.21cse@sonatech.ac.in niveditha.21cse@sonatech.ac.in pavadarshini.21cse@sonatech.ac.in ponnarasan.21cse@sonatech.ac.in pooja.21cse@sonatech.ac.in poojashri.21cse@sonatech.ac.in prabhu.21cse@sonatech.ac.in pragashini.21cse@sonatech.ac.in pranavjadhav.21cse@sonatech.ac.in pranesh.21cse@sonatech.ac.in prasanth.21cse@sonatech.ac.in prateeka.21cse@sonatech.ac.in praveenkumar.21cse@sonatech.ac.in pravinaroselin.21cse@sonatech.ac.in pravishna.21cse@sonatech.ac.in priyadharshini.21cse@sonatech.ac.in priyanga.21cse@sonatech.ac.in ragulkrishna.21cse@sonatech.ac.in rajsachin.21cse@sonatech.ac.in rakshambhiga.21cse@sonatech.ac.in ramamoorthi.21cse@sonatech.ac.in rammkumaran.21cse@sonatech.ac.in ranil.21cse@sonatech.ac.in rashigapriya.21cse@sonatech.ac.in raveeswaran.21cse@sonatech.ac.in reshma.21cse@sonatech.ac.in rithika.21cse@sonatech.ac.in rupasrissantana.21cse@sonatech.ac.in sachinmathew.21cse@sonatech.ac.in sandipnarayanan.21cse@sonatech.ac.in sanyogita.21cse@sonatech.ac.in sarmudhi.21cse@sonatech.ac.in ashiqahmed.21cse@sonatech.ac.in deepakvijay.21cse@sonatech.ac.in jayakumar.21cse@sonatech.ac.in kirthisri.21cse@sonatech.ac.in nandha.21cse@sonatech.ac.in sasikumar.21cse@sonatech.ac.in senthilkumars.21cse@sonatech.ac.in senthilkumarp.21cse@sonatech.ac.in shanmathi.21cse@sonatech.ac.in sharumathi.21cse@sonatech.ac.in shrisowmiya.21cse@sonatech.ac.in sibiraj.21cse@sonatech.ac.in siddharthbalaji.21cse@sonatech.ac.in soundararajan.21cse@sonatech.ac.in sowmiya.21cse@sonatech.ac.in srijagathvibhav.21cse@sonatech.ac.in sriram.21cse@sonatech.ac.in sudhakar.21cse@sonatech.ac.in suganya.21cse@sonatech.ac.in Sujithak.21cse@sonatech.ac.in sujithas.21cse@sonatech.ac.in Sumi.21cse@sonatech.ac.in supreetha.21cse@sonatech.ac.in sureka.21cse@sonatech.ac.in sureshkrisna.21cse@sonatech.ac.in surya.21cse@sonatech.ac.in suseendrakumar.21cse@sonatech.ac.in sushmitha.21cse@sonatech.ac.in swetha.21cse@sonatech.ac.in tamizharasi.21cse@sonatech.ac.in tharaneeshwar.21cse@sonatech.ac.in tharikha.21cse@sonatech.ac.in thirunavukkarasu.21cse@sonatech.ac.in thirunithish. 21cse@sonatech.ac.in thrishu.21cse@sonatech.ac.in thrissapriya.21cse@sonatech.ac.in tulasidharan.21cse@sonatech.ac.in varsha.21cse@sonatech.ac.in varshaa.21cse@sonatech.ac.in venkatesh.21cse@sonatech.ac.in vidya.21cse@sonatech.ac.in vignesh.21cse@sonatech.ac.in vijayprem.21cse@sonatech.ac.in vijayrajan.21cse@sonatech.ac.in vijayarani. 21cse@sonatech.ac.in vishal.21cse@sonatech.ac.in yashhwanthini.21cse@sonatech.ac.in yogeshwaran.21cse@sonatech.ac.in yuvankumar.21cse@sonatech.ac.in anbazhagan.21cse@sonatech.ac.in kabilmanikandan.21cse@sonatech.ac.in krishnakanth.21cse@sonatech.ac.in mohammedhussain.21cse@sonatech.ac.in sabarivasan.21cse@sonatech.ac.in Sriharisiranjeevi.21cse@sonatech.ac.in srinath.21cse@sonatech.ac.in suryavikram.21cse@sonatech.ac.in abdulgafoor.20cse@sonatech.ac.in abdulkalamashik.20cse@sonatech.ac.in abinaya.20cse@sonatech.ac.in abinayam.20cse@sonatech.ac.in abinayaki.20cse@sonatech.ac.in ajayaaditya.20cse@sonatech.ac.in ajithmon.20cse@sonatech.ac.in ajithkumar.20cse@sonatech.ac.in akashpraveen.20cse@sonatech.ac.in aleena.20cse@sonatech.ac.in anilkumar.20cse@sonatech.ac.in aravind.20cse@sonatech.ac.in areddulanaveenkumar.20cse@sonatech.ac.in ashmithalaxmi.20cse@sonatech.ac.in ashwathraj.20cse@sonatech.ac.in ashwin.20cse@sonatech.ac.in ashwithasree.20cse@sonatech.ac.in aswin.20cse@sonatech.ac.in balaji.20cse@sonatech.ac.in balamurugan.20cse@sonatech.ac.in baranihari.20cse@sonatech.ac.in brijesh.20cse@sonatech.ac.in charumathi.20cse@sonatech.ac.in daksanya.20cse@sonatech.ac.in deenadhayalan.20cse@sonatech.ac.in deepadharsan.20cse@sonatech.ac.in dhanushg.20cse@sonateach.ac.in dhanushm.20cse@sonatech.ac.in dhanushv.20cse@sonatech.ac.in dhanusree.20cse@sonatech.ac.in dharshinik.20cse@sonatech.ac.in dharshinim.20cse@sonatech.ac.in dharshni.20cse@sonatech.ac.in durai.20cse@sonatech.ac.in elansuriyaa.20cse@sonatech.ac.in gayathrip.20cse@sonatech.ac.in gogulkanth.20cse@sonatech.ac.in joelgeorgesam.20cse@sonatech.ac.in chakra.20cse@sonatech.ac.in naiduakash.20cse@sonatech.ac.in akash.20cse@sonatech.ac.in akasthiya.20cse@sonatech.ac.in dhanushwar.20cse@sonatech.ac.in gnaneswari.20cse@sonatech.ac.in mohansundareshan.20cse@sonatech.ac.in gokul.20cse@sonatech.ac.in gokulakrishnan.20cse@sonatech.ac.in guruprasath.20cse@sonatech.ac.in hajira.20cse@sonatech.ac.in hariharasudhan.20cse@sonatech.ac.in harinisoundaryaa.20cse@sonatech.ac.in hariprasanth.20cse@sonatech.ac.in haripriya.20cse@sonatech.ac.in ilakiya.20cse@sonatech.ac.in jayaakshara.20cse@sonatech.ac.in jeyasree.20cse@sonatech.ac.in kanishakar.20cse@sonatech.ac.in karksih.20cse@sonatech.ac.in karthibalaji.20cse@sonatech.ac.in karthickraj.20cse@sonatech.ac.in Karuppasamy.20cse@sonatech.ac.in kavin.20cse@sonatech.ac.in kavipriya.20cse@sonatech.ac.in kaviya.20cse@sonatech.ac.in kaviyadharshini.20cse@sonatech.ac.in kishore.20cse@sonatech.ac.in kousikapriya.20cse@sonatech.ac.in krisnapriya.20cse@sonatech.ac.in krithika.20cse@sonatech.ac.in logaveeraraj.20cse@sonatech.ac.in madhumitha.20cse@sonatech.ac.in manishragavan.20cse@sonatech.ac.in manivannan.20cse@sonatech.ac.in manojp.20cse@sonatech.ac.in manojs.20cse@sonatech.ac.in meenakshi.20cse@sonatech.ac.in mohamedathil.20cse@sonatech.ac.in monishprasad.20cse@sonatech.ac.in moulieswaren.20cse@sonatech.ac.in lakshmipriya.20cse@sonatech.ac.in inbaraj.20cse@sonatech.ac.in jana.20cse@sonatech.ac.in kavinbharathi.20cse@sonatech.ac.in kesavan.20cse@sonatech.ac.in naveenkumar.20cse@sonatech.ac.in senthilkumar.20cse@sonatech.ac.in sreeganth.20cse@sonatech.ac.in srihariraj.20cse@sonatech.ac.in suryaprakash.20cse@sonatech.ac.in jayereesh.19cse@sonatech.ac.in navroj.22cse@sonatech.ac.in priyankha.20cse@sonatech.ac.in sakthibala.20cse@sonatech.ac.in neelakshi.20cse@sonatech.ac.in kannan.20cse@sonatech.ac.in ragul.20cse@sonatech.ac.in prem.20cse@sonatech.ac.in sabarish.20cse@sonatech.ac.in sarvesh.20cse@sonatech.ac.in nikhil.20cse@sonatech.ac.in nithin.20cse@sonatech.ac.in naveenkumar.20cse@sonatech.ac.in sakthy.20cse@sonatech.ac.in nirmalraj.20cse@sonatech.ac.in saravinth.20cse@sonatech.ac.in nirmals.20cse@sonatech.ac.in rampachan.20cse@sonatech.ac.in prasad.20cse@sonatech.ac.in sandya.20cse@sonatech.ac.in naagavarshini.20cse@sonatech.ac.in pavithra.20cse@sonatech.ac.in rajvignesh.20cse@sonatech.ac.in pavitra.20cse@sonatech.ac.in praveen.20cse@sonatech.ac.in priyadharshini.20cse@sonatech.ac.in pavithras.20cse@sonatech.ac.in naveenbalaji.20cse@sonatech.ac.in nandhini.20cse@sonatech.ac.in narendran.20cse@sonatech.ac.in rohithkannan.20cse@sonatech.ac.in nirmalj.20cse@sonatech.ac.in priyadharshinig.20cse@sonatech.ac.in santhoshkumar.20cse@sonatech.ac.in rohitha.20cse@sonatech.ac.in purnanchale.20cse@sonatech.ac.in naveen.20cse@sonatech.ac.in naveengowtham.20cse@sonatech.ac.in nishitha.20cse@sonatech.ac.in mugilptasath.20cse@sonatech.ac.in nirmals.20cse@sonatech.ac.in saran.20cse@sonatech.ac.in prithvisri.20cse@sonatech.ac.in sedhuragavan.20cse@sonatech.ac.in shalini.20cse@sonatech.ac.in shankar.20cse@sonatech.ac.in sharmi.20cse@sonatech.ac.in shreedharan.20cse@sonatech.ac.in shrilekha.20cse@sonatech.ac.in sibivignesh.20cse@sonatech.ac.in sneha.20cse@sonatech.ac.in sooraj.20cse@sonatech.ac.in soundarya.20cse@sonatech.ac.in sriarthi.20cse@sonatech.ac.in sripauldaniel.20cse@sonatech.ac.in sridevi.20cse@sonatech.ac.in sridharshini.20cse@sonatech.ac.in srikanth.20cse@sonatech.ac.in srikar.20cse@sonatech.ac.in srimathi.20cse@sonatech.ac.in subhiksha.20cse@sonatech.ac.in sudha.20cse@sonatech.ac.in sudharshan.20cse@sonatech.ac.in suhaib.20cse@sonatech.ac.in sundhara.20cse@sonatech.ac.in sundhars.20cse@sonatech.ac.in swathi.20cse@sonatech.ac.in swetha.20cse@sonatech.ac.in swethaa.20cse@sonatech.ac.in tharunkumar.20cse@sonatech.ac.in tharun.20cse@sonatech.ac.in thirukumara.20cse@sonatech.ac.in thrisha.20cse@sonatech.ac.in vaishnavi.20cse@sonatech.ac.in varsha.20cse@sonatech.ac.in varshinil.20cse@sonatech.ac.in varshinim.20cse@sonatech.ac.in varshitha.20cse@sonatech.ac.in vasudevan.20cse@sonatech.ac.in vijay.20cse@sonatech.ac.in visnuyaathav.20cse@sonatech.ac.in yagavi.20cse@sonatech.ac.in yokeshkumar.20cse@sonatech.ac.in yuvaraj.20cse@sonatech.ac.in sanjayraj.20cse@sonatech.ac.in sarankumar.20cse@sonatech.ac.in sutharsun.20cse@sonatech.ac.in vijayl.20cse@sonatech.ac.in yuvas.20cse@sonatech.ac.in"

var hiddenDiv = document.getElementById("hiddenDiv");
var hiddenDiv1 = document.getElementById("hiddenDiv1");
var workshopName = document.getElementById("workshop");


function showDiv() {
    
    hiddenDiv.style.display = "block";
}

function hideDiv() {
    hiddenDiv.style.display = "none";
}

function showDiv1() {
   
    hiddenDiv1.style.display = "block";
    if(workshopName.checked == false) {
        hideDiv1();
    }
}

function hideDiv1() {
    hiddenDiv1.style.display = "none";
}



function preventReload(event) {
    event.preventDefault();
}

const workshopRegis=document.querySelector(".workshopRegis");
const transId=document.querySelector(".transId");
var nextBtn = document.getElementById("nextBtn");
nextBtn.addEventListener("click", event => {
    event.preventDefault();
    var named = document.getElementById('canditateName').value
    var ele = document.getElementsByName('Colleger');
    for(i = 0; i < ele.length; i++) {
        if(ele[i].checked){
                if(ele[i].value == "Sona College Of Technology"){
                    var Colleged = "Sona College Of Technology";
                }
                else if(ele[i].value == "Others"){
                    var Colleged = document.getElementById('clgName').value
                }
        }
    }
    var events = document.getElementById("event"); 
    if (events.checked == true){
        var eventsd = "yes";
    }
    else{
        var eventsd = "no";
    }
    
    var workshops = document.getElementById("workshop"); 
    if (workshops.checked == true){
        var rai = document.getElementsByName('workshop1');
        for(i = 0; i < rai.length; i++) {
            if(rai[i].checked){
                    if(rai[i].value == "Robotic Process Automation"){
                        var workshopsd = "Robotic Process Automation";
                    }
                    else if(rai[i].value == "Android App Development"){
                        var workshopsd = "Android App Development";
                    }
                    else if(rai[i].value == "Internet Of Things"){
                        var workshopsd = "Internet Of Things";
                    }
                    else if(rai[i].value == null){
                        var workshopsd = "Robotic Process Automation";
                    }
            }
            else{
            }
        }
    }
    else if(workshops.checked == false){
        var workshopsd = "not intrested";
    }
    var deptd = document.getElementById('dept').value; 

    var rai1 = document.getElementsByName('year');
        for(i = 0; i < rai1.length; i++) {
            if(rai1[i].checked){
                    if(rai1[i].value == "1"){
                        var yeard = "1";
                    }
                    else if(rai1[i].value == "2"){
                        var yeard = "2";
                    }
                    else if(rai1[i].value == "3"){
                        var yeard = "3";
                    }
                    else if(rail[i].value == "4"){
                        var yeard = "4";
                    }
            }
            else{
            }
        }
        var phoned = document.getElementById('contactNo').value;
    var emaild = document.getElementById('email').value;

    if(named==""||Colleged==""||deptd==""||yeard==""||phoned==""||emaild=="")
    {
        transId.style.display="none"
        workshopRegis.style.display="block";
        swal("Enter All Data Asked In The Form")
    }
    else if(workshopsd==""&&eventsd=="")
    {
        transId.style.display="none"
        workshopRegis.style.display="block";
        swal("Select Either Workshop Are Event In The Given Form")
    }
    else
    {
        if(message.includes(emaild))
        { 
            console.log("1")
            let emailchk=""
            let emailch=[]
            let unid=""
            let conid=""
            dbRef.child("userdata").child("findid").get().then((snapshot) => { 
                console.log("3")
                console.log(snapshot)
                snapshot.forEach(function(childSnapshot) {
                    var data = childSnapshot.val();
                    console.log("4")
                    console.log(data)
                    console.log("vv")
                   emailch=data.emailid;
                   console.log(emailch)
                   unid=data.id;
                    for(var k=0;k<emailch.length;k++)
                    {
                        console.log("5")
                        if(emailch==emaild)
                             {
                                console.log("6")
                                 emailchk=emaild;
                                conid=unid;
                            }

                            if(emailchk=="")
                            {
                                            console.log(eventsd)
                                            console.log("7")
                                        
                                            transId.style.display="none"
                                    workshopRegis.style.display="block";
                                    let length="";
                                   
                                    if(eventsd== "yes")
                                    {
                                        const dbRef = firebase.database().ref()
                                        dbRef.child("userdata").child("value").get().then((snapshot) => { 
                                            if (snapshot.exists()) {
                                                let sydat = snapshot.val();
                                                length=sydat.value+1;
                                            }
                                        }).then(()=>{
                                            databas.ref("userdata").child("findid").child("THCSE"+length).set({
                                                id : "THCSE"+length,
                                                emailid:emaild
                                            })
                                            databas.ref("userdata").child("user").child("THCSE"+length).set({
                                                id : "THCSE"+length,
                                                Name : named,
                                                college : Colleged ,
                                                Email : emaild ,
                                                Phoneno : phoned,
                                                Year:yeard,
                                                Dept:deptd,
                                                Event:eventsd,
                                                workshop:workshopsd,
                                
                                            }).then(()=>{
                                                databas.ref("userdata").child("value").set({
                                                    value:length
                                                }).then(()=>{
                                                    swal({
                                                        title : "Download Your IDcard In our Website, After 24 Hours.",
                                                        icon : 'success'
                                                    })
                                                    hiddenDiv.style.display = "none";
                                                    document.querySelector('#workshopRegis').reset()
                                                })
                                            })
                                        })
                                    }
                                    else
                                    {
                                        swal("you must select only events here")
                                    }
                                           
                                        
                       
                            }
                            
                    }
                })
               
                    transId.style.display="none"
                    workshopRegis.style.display="block";
                    let length="";
    
                        databas.ref("userdata").child("user").child(conid).update({
                            Event:eventsd,
                            workshop:workshopsd,
              
                        }).then(()=>{
                                swal({
                                    title : "Download Your IDcard In our Website, After 24 Hours.",
                                    icon : 'success'
                                })
                                hiddenDiv.style.display = "none";
                                document.querySelector('#workshopRegis').reset()
                            })
                        
                    
            
             

            })

            
        }
        else
        {
            
            workshopRegis.style.display="none";
            transId.style.display="block"

        const qrImg = document.querySelector('#qrImg')
        const qrImg2 = document.querySelector('#qrImg2')
        const qrImg1 = document.querySelector('#qrImg1')
    if (events.checked == true && workshops.checked == true){  
        qrImg2.style.display = "none"
        qrImg1.style.display = "none"
        qrImg.style.display = "block"
       
      }  
      else if (workshops.checked == true){
        qrImg1.style.display = "none"
        qrImg.style.display = "none"
        qrImg2.style.display = "block"
        
      }
      else if (events.checked == true){
        qrImg.style.display = "none"
        qrImg2.style.display = "none"
        qrImg1.style.display = "block"
      }

      

      var submitBtn = document.getElementById("submitBtn");
      submitBtn.addEventListener("click", event => {
            let transactiond = document.getElementById('transId').value;

            if(transactiond=="")
            {
                swal("Enter Your UPI Transaction Id ")
                workshopRegis.style.display="none";
                transId.style.display="block"
            }
            else
            {
                
                database.ref("userdata").child("unregister").child(transactiond).set({
                    name : named,
                    email :  emaild,
                    dept : deptd,
                    year : yeard,
                    clg : Colleged,
                    phone : phoned,
                    event : eventsd,
                    workshop : workshopsd,
                    transactionid : transactiond
               
                }).then(()=>{
                        swal({
                            title : "Download Your IDcard In our Website, After 24 Hours. ",
                            icon : 'success'
                        })
                        document.querySelector('#workshopRegis').reset()
                        document.querySelector('#transId').value="";
                        transId.style.display="none";
                        hiddenDiv.style.display = "none";
                        workshopRegis.style.display="block";
                       
                       
                    })
            }

        })
        }
        

      



    }


})