var menu = document.getElementById("navOptions");

function menuSlide() {
    menu.style.display = "block"
}

function closeSlide() {
    menu.style.display = "none"
}